// bookingofbusticket.java
// A complete Bus Ticket Booking System using Swing + JDBC (XAMPP MySQL)
// Author: ChatGPT
// Note: Make sure MySQL Connector/J JAR is added to your NetBeans project libraries.

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class bookingofbusticket extends JFrame {
    
    private final JTextField tfSource = new JTextField();
    private final JTextField tfDestination = new JTextField();
    private final JTextField tfDate = new JTextField(LocalDate.now().toString());
    private final JTable tblResults = new JTable();

    private final JTextField tfCustName = new JTextField();
    private final JTextField tfCustPhone = new JTextField();
    private final JTextField tfCustEmail = new JTextField();
    private final JTextField tfSeats = new JTextField("1");
    private final JLabel lbFarePreview = new JLabel("Fare: -");

    private final JTable tblBookings = new JTable();
    private final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public bookingofbusticket() {
        super("Bus Ticket Booking System — Swing + JDBC");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1080, 720);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Search & Book", buildSearchTab());
        tabs.add("My Bookings", buildBookingsTab());
        setContentPane(tabs);

        loadBookings();
    }

    private JPanel buildSearchTab() {
        JPanel root = new JPanel(new BorderLayout(8, 8));

        JPanel search = new JPanel(new GridLayout(2, 5, 8, 8));
        search.setBorder(BorderFactory.createTitledBorder("Search Buses"));
        search.add(new JLabel("Source"));
        search.add(new JLabel("Destination"));
        search.add(new JLabel("Travel Date (YYYY-MM-DD)"));
        search.add(new JLabel());
        search.add(new JLabel());

        search.add(tfSource);
        search.add(tfDestination);
        search.add(tfDate);
        JButton btnSearch = new JButton("Search");
        JButton btnReset = new JButton("Reset");
        search.add(btnSearch);
        search.add(btnReset);

        btnSearch.addActionListener(e -> performSearch());
        btnReset.addActionListener(e -> {
            tfSource.setText("");
            tfDestination.setText("");
            tfDate.setText(LocalDate.now().toString());
        });

        String[] cols = {"Bus ID", "Bus No", "Route", "Travel Date", "Depart", "Arrive", "Total Seats", "Available", "Base Fare"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblResults.setModel(model);
        tblResults.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane sp = new JScrollPane(tblResults);
        sp.setBorder(BorderFactory.createTitledBorder("Available Buses"));

        JPanel booking = new JPanel(new GridLayout(7, 2, 8, 8));
        booking.setBorder(BorderFactory.createTitledBorder("Create Booking"));
        booking.add(new JLabel("Customer Name"));
        booking.add(tfCustName);
        booking.add(new JLabel("Phone"));
        booking.add(tfCustPhone);
        booking.add(new JLabel("Email"));
        booking.add(tfCustEmail);
        booking.add(new JLabel("Seats"));
        booking.add(tfSeats);
        JButton btnCalcFare = new JButton("Preview Fare");
        JButton btnBook = new JButton("Book Ticket");
        booking.add(btnCalcFare);
        booking.add(btnBook);
        booking.add(new JLabel());
        booking.add(lbFarePreview);
        booking.add(new JLabel("Tip: Select a bus row first"));
        JButton btnRefreshBookings = new JButton("Refresh Bookings");
        booking.add(btnRefreshBookings);

        btnCalcFare.addActionListener(e -> previewFare());
        btnBook.addActionListener(e -> createBooking());
        btnRefreshBookings.addActionListener(e -> loadBookings());

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sp, booking);
        split.setResizeWeight(0.75);

        root.add(search, BorderLayout.NORTH);
        root.add(split, BorderLayout.CENTER);
        return root;
    }

    private JPanel buildBookingsTab() {
        JPanel root = new JPanel(new BorderLayout(8, 8));
        String[] cols = {"Booking ID", "Customer", "Phone", "Email", "Bus No", "Route", "Date", "Seats", "Amount", "Status", "Booked At"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblBookings.setModel(model);
        tblBookings.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnReload = new JButton("Reload");
        JButton btnCancel = new JButton("Cancel Selected");
        actions.add(btnReload);
        actions.add(btnCancel);
        btnReload.addActionListener(e -> loadBookings());
        btnCancel.addActionListener(e -> cancelSelectedBooking());

        root.add(actions, BorderLayout.NORTH);
        root.add(new JScrollPane(tblBookings), BorderLayout.CENTER);
        return root;
    }

    private void performSearch() {
        String src = tfSource.getText().trim();
        String dst = tfDestination.getText().trim();
        String date = tfDate.getText().trim();
        if (src.isEmpty() || dst.isEmpty() || date.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter source, destination, and date (YYYY-MM-DD).");
            return;
        }
        try {
            LocalDate.parse(date, DATE_FMT);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Use YYYY-MM-DD.");
            return;
        }

        String sql = "SELECT b.id, b.bus_no, CONCAT(r.source, ' → ', r.destination) AS route, b.travel_date, b.departure_time, b.arrival_time, b.seats_total, b.seats_available, r.base_fare " +
                     "FROM buses b JOIN routes r ON b.route_id = r.id " +
                     "WHERE r.source LIKE ? AND r.destination LIKE ? AND b.travel_date = ?";
        try (Connection con = DB.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, src + "%");
            ps.setString(2, dst + "%");
            ps.setString(3, date);
            ResultSet rs = ps.executeQuery();
            DefaultTableModel m = (DefaultTableModel) tblResults.getModel();
            m.setRowCount(0);
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDate(4),
                    rs.getTime(5), rs.getTime(6), rs.getInt(7), rs.getInt(8), rs.getBigDecimal(9)
                });
            }
            if (m.getRowCount() == 0) JOptionPane.showMessageDialog(this, "No buses found.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void previewFare() {
        int row = tblResults.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a bus first."); return; }
        int seats;
        try { seats = Integer.parseInt(tfSeats.getText().trim()); }
        catch (Exception ex) { JOptionPane.showMessageDialog(this, "Enter seats as a number."); return; }
        if (seats <= 0) { JOptionPane.showMessageDialog(this, "Seats must be > 0."); return; }

        Object baseFareObj = tblResults.getValueAt(row, 8);
        java.math.BigDecimal baseFare = new java.math.BigDecimal(baseFareObj.toString());
        java.math.BigDecimal amount = baseFare.multiply(new java.math.BigDecimal(seats));
        lbFarePreview.setText("Fare: " + amount.toPlainString());
    }

    private void createBooking() {
        int row = tblResults.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a bus first."); return; }
        int busId = (int) tblResults.getValueAt(row, 0);
        int available = Integer.parseInt(tblResults.getValueAt(row, 7).toString());

        String name = tfCustName.getText().trim();
        String phone = tfCustPhone.getText().trim();
        String email = tfCustEmail.getText().trim();
        int seats;
        try { seats = Integer.parseInt(tfSeats.getText().trim()); }
        catch (Exception ex) { JOptionPane.showMessageDialog(this, "Enter seats as number."); return; }

        if (name.isEmpty() || phone.isEmpty() || seats <= 0) {
            JOptionPane.showMessageDialog(this, "Enter customer name, phone, and valid seats.");
            return;
        }
        if (seats > available) {
            JOptionPane.showMessageDialog(this, "Not enough seats available.");
            return;
        }

        try (Connection con = DB.getConnection()) {
            con.setAutoCommit(false);

            String insertUser = "INSERT INTO users(name, phone, email) VALUES(?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name), email=VALUES(email)";
            String getUserId = "SELECT id FROM users WHERE phone=?";
            String fareSql = "SELECT r.base_fare FROM buses b JOIN routes r ON b.route_id=r.id WHERE b.id=?";
            String updateSeats = "UPDATE buses SET seats_available = seats_available - ? WHERE id=? AND seats_available >= ?";
            String insertBooking = "INSERT INTO bookings(user_id, bus_id, seats, amount, status) VALUES(?,?,?,?, 'CONFIRMED')";

            PreparedStatement psUser = con.prepareStatement(insertUser);
            psUser.setString(1, name);
            psUser.setString(2, phone);
            psUser.setString(3, email);
            psUser.executeUpdate();

            PreparedStatement psGetUser = con.prepareStatement(getUserId);
            psGetUser.setString(1, phone);
            ResultSet rsUser = psGetUser.executeQuery();
            rsUser.next();
            int userId = rsUser.getInt(1);

            PreparedStatement psFare = con.prepareStatement(fareSql);
            psFare.setInt(1, busId);
            ResultSet rsFare = psFare.executeQuery();
            rsFare.next();
            java.math.BigDecimal baseFare = rsFare.getBigDecimal(1);
            java.math.BigDecimal amount = baseFare.multiply(new java.math.BigDecimal(seats));

            PreparedStatement psUpdate = con.prepareStatement(updateSeats);
            psUpdate.setInt(1, seats);
            psUpdate.setInt(2, busId);
            psUpdate.setInt(3, seats);
            int updated = psUpdate.executeUpdate();
            if (updated == 0) throw new SQLException("Seat update failed.");

            PreparedStatement psBook = con.prepareStatement(insertBooking);
            psBook.setInt(1, userId);
            psBook.setInt(2, busId);
            psBook.setInt(3, seats);
            psBook.setBigDecimal(4, amount);
            psBook.executeUpdate();

            con.commit();
            JOptionPane.showMessageDialog(this, "Booking successful! Amount: " + amount);
            performSearch();
            loadBookings();
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void loadBookings() {
        String sql = "SELECT bk.id, u.name, u.phone, u.email, b.bus_no, CONCAT(r.source,' → ',r.destination) AS route, b.travel_date, bk.seats, bk.amount, bk.status, bk.booked_at " +
                     "FROM bookings bk JOIN users u ON bk.user_id=u.id " +
                     "JOIN buses b ON bk.bus_id=b.id JOIN routes r ON b.route_id=r.id ORDER BY bk.booked_at DESC";
        try (Connection con = DB.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            DefaultTableModel m = (DefaultTableModel) tblBookings.getModel();
            m.setRowCount(0);
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
                    rs.getString(5), rs.getString(6), rs.getDate(7), rs.getInt(8),
                    rs.getBigDecimal(9), rs.getString(10), rs.getTimestamp(11)
                });
            }
        } catch (SQLException e) { showError(e); }
    }

    private void cancelSelectedBooking() {
        int row = tblBookings.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select a booking to cancel."); return; }
        int bookingId = (int) tblBookings.getValueAt(row, 0);
        int seats = Integer.parseInt(tblBookings.getValueAt(row, 7).toString());
        String getBus = "SELECT bus_id FROM bookings WHERE id=? AND status='CONFIRMED'";
        String cancel = "UPDATE bookings SET status='CANCELLED' WHERE id=? AND status='CONFIRMED'";
        String addSeats = "UPDATE buses SET seats_available = seats_available + ? WHERE id=?";
        try (Connection con = DB.getConnection()) {
            con.setAutoCommit(false);
            PreparedStatement ps1 = con.prepareStatement(getBus);
            ps1.setInt(1, bookingId);
            ResultSet rs = ps1.executeQuery();
            if (!rs.next()) { JOptionPane.showMessageDialog(this, "Already cancelled."); return; }
            int busId = rs.getInt(1);

            PreparedStatement ps2 = con.prepareStatement(cancel);
            ps2.setInt(1, bookingId);
            ps2.executeUpdate();

            PreparedStatement ps3 = con.prepareStatement(addSeats);
            ps3.setInt(1, seats);
            ps3.setInt(2, busId);
            ps3.executeUpdate();

            con.commit();
            JOptionPane.showMessageDialog(this, "Booking cancelled successfully.");
            loadBookings();
        } catch (SQLException e) { showError(e); }
    }

    private void showError(Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    // ✅ MAIN METHOD
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new bookingofbusticket().setVisible(true));
    }
}

// --- Database Connection Helper ---
class DB {
    private static final String URL = "jdbc:mysql://localhost:3306/bus_booking?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";  // default XAMPP username
    private static final String PASS = "";      // default XAMPP password (empty)

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC Driver not found. Add mysql-connector-j.jar to classpath.");
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
